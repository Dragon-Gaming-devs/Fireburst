import { version } from './package.json';
export default (await import(`https://cxrtnc.leaningtech.com/${version}/cx.esm.js`)).default;
